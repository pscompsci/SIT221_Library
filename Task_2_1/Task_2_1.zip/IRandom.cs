namespace Task_2_1
{
    public interface IRandom
    {
        public double rand();
    }
}